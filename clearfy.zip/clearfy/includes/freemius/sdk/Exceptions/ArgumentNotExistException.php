<?php
    class WCL_Freemius_ArgumentNotExistException extends WCL_Freemius_InvalidArgumentException { }