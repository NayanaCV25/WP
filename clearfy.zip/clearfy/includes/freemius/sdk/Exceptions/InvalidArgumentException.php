<?php
    class WCL_Freemius_InvalidArgumentException extends WCL_Freemius_Exception { }