<?php

	class WCL_Freemius_OAuthException extends WCL_Freemius_Exception {

		public function __construct($pResult)
		{
			parent::__construct($pResult);
		}
	}