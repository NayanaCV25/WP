<?php
    class WCL_Freemius_EmptyArgumentException extends WCL_Freemius_InvalidArgumentException { }