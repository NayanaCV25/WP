=== HTML optimization  ===
Tags: html optimization
Contributors: webcraftic
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=VDX7JNTQPNPFW
Requires at least: 4.2
Tested up to: 4.9
Requires PHP: 5.2
Stable tag: trunk
License: GPLv2

= 1.0.0 =
* Plugin release

= 0.0.1 =
* Plugin beta