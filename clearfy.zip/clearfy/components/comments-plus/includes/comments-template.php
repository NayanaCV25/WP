<?php
/* Dummy comments template file.
 * This replaces the theme's comment template when comments are disabled everywhere
 */