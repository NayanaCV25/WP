<?php

	/**
	 * Activator for the Update manager
	 * @author Webcraftic <wordpress.webraftic@gmail.com>
	 * @copyright (c) 09.09.2017, Webcraftic
	 * @see Factory409_Activator
	 * @version 1.0
	 */

	// Exit if accessed directly
	if( !defined('ABSPATH') ) {
		exit;
	}

	class WUPM_Activation extends Wbcr_Factory409_Activator {

		/**
		 * Runs activation actions.
		 *
		 * @since 1.0.0
		 */
		public function activate()
		{

		}

		/**
		 * Runs deactivation actions.
		 *
		 * @since 1.0.0
		 */
		public function deactivate()
		{

		}


	}
