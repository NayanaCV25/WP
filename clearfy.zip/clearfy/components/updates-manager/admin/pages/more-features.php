<?php

	/**
	 * The page Settings.
	 *
	 * @since 1.0.0
	 */

	// Exit if accessed directly
	if( !defined('ABSPATH') ) {
		exit;
	}

	class WbcrUpm_MoreFeaturesPage extends Wbcr_FactoryClearfy206_MoreFeaturesPage {

	}
